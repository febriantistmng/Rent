from flask import Flask,request,url_for,jsonify,send_from_directory
import decimal
import flask.json
import hashlib
import datetime 
import pymysql.cursors
import os
import random
import string
from flask_mail import Mail,Message

def random_char(y):
       return ''.join(random.choice(string.ascii_letters) for x in range(y))

class MyJSONEncoder(flask.json.JSONEncoder):
    def default(self, obj):
        print(str(obj))
        if isinstance(obj, decimal.Decimal):
            # Convert decimal instances to strings.
            return str(obj)
        if isinstance(obj, (datetime.date, datetime.datetime,datetime.timedelta)):
            return ""+str(obj)+""
        return super(MyJSONEncoder, self).default(obj)
conn=cursor=None
UPLOAD_FOLDER = 'product-images'
uploadpath=os.path.join(os.getcwd(),UPLOAD_FOLDER)
def openDb():
    global conn,cursor
    conn=pymysql.connect(host="localhost",user="root",password="",database="rentall")
    cursor=conn.cursor(pymysql.cursors.DictCursor)
def closeDb():
    cursor.close()
    conn.close()
app=Flask(__name__)
app.config['MAIL_SERVER']='smtp.gmail.com'
app.config['MAIL_PORT'] = 465
app.config['MAIL_USERNAME'] = 'mailerfrees@gmail.com'
app.config['MAIL_PASSWORD'] = 'freesmailer29'
app.config['MAIL_USE_TLS'] = False
app.config['MAIL_USE_SSL'] = True
mail = Mail(app)
app.json_encoder = MyJSONEncoder
@app.route('/')
def index():
    return "hola"
@app.route('/products')
def getFields():
   container=[]
   openDb()
   cursor.execute("Select * from product")
   data=cursor.fetchall()
   for field in data:
       cursor.execute("Select * from spec where id_products=%s",field['id_products'])
       field["spec"]=cursor.fetchone()
       container.append(field)
   closeDb()
   return jsonify(container)
@app.route('/profile/<id>/book')
def getBookList(id):
   
   container=[]
   openDb()
   cursor.execute("Select * from booking  where id_user=%s",(id))
   data=cursor.fetchall()
   for order in data:
     cursor.execute("select * from product where id_products =%s",(order["id_product"]))
     product=cursor.fetchone()
     order["product"]=product
     container.append(order)
   closeDb()
   return jsonify(container)
   
@app.route('/review/<id_product>')
def review(id_product):
   openDb()
   container=[]
   cursor.execute("Select id_booking from booking where id_product=%s",(id_product))
   dataid=cursor.fetchall()
   for id in dataid:
    cursor.execute("Select * from reviews where id_booking=%s",id["id_booking"])
    data=cursor.fetchone()
    if data!=None:
      container.append(data)
   closeDb()
   return jsonify(container)
@app.route('/review/create', methods=['POST'])
def addreview():
  map=request.form
  sql="REPLACE INTO `reviews` (`id_booking`, `review`, `rate`)"
  sql+=" VALUES (%s, %s, %s);"
  openDb()
  try:
    cursor.execute(sql,(map['id_booking'],map['review'],map['rate']))
    conn.commit()
    closeDb()
    return jsonify({
      "result":True,
      "message":"success add review"
    })
  except Exception as e:
    closeDb()
    return jsonify({
      "result":False,
      "message":"cannot process you\'re request, try later"
    })
@app.route('/auth/login', methods=['POST'])
def login():
   map=request.form
   password=hashlib.sha1(map['password'].encode()).hexdigest()
   sql="select count(*) as result,email,id_user as uid from user where email=%s AND password=%s"
   val=(map['email'],password)
   print("select count(*) as result,email,id_user as uid from user where email="+val[0]+" AND password="+val[1])
   openDb()
   cursor.execute(sql,val)
   result = cursor.fetchone()
   
   result['message']="Login Success" if result['result']>0 else "login not success"
   if(result['result']==1):
       result['data']={
           "email":result['email'],
           "uid":result['uid'],
       }
   closeDb()
   result['result']=True if result['result']>0 else False
   return jsonify(result)

@app.route('/auth/register', methods=['POST'])
def register():
   map=request.form
   sql="select count(*) as result from user where email=%s"
   val=(map['email'])

   openDb()
   cursor.execute(sql,val)
   result=cursor.fetchone()
   if (result['result']>0):
       closeDb()
       result['message']="email has been used"
       result['result']=False
       return jsonify(result)
   else:
       password=hashlib.sha1(map['password'].encode()).hexdigest()
       sql="INSERT INTO `user`"
       sql+="(`email`, `password`,`name`)"
       sql+=" VALUES (%s,%s,%s)"
       val=(map['email'],password,map['name'])
       cursor.execute(sql,val)
       conn.commit()
       sql="select count(email) as result,email,id_user as uid from user where email=%s AND password=%s"
       val=(map['email'],password)
       cursor.execute(sql,val)
       results={

       }
       result = cursor.fetchone()
       if(result['result']==1):
            results['data']={
                "email":result['email'],
                "uid":result['uid'],
            } 
       closeDb()
       results['result']=True
       results['message']="register success"
       return jsonify(results)

@app.route('/profile/<id>/details')
def getProfile(id):
   sql="SELECT * FROM `user` WHERE id_user=%s"
   openDb()
   cursor.execute(sql,(id))
   data=cursor.fetchone()
   data["password"]="*********"
   closeDb()
   if data==None:
       return jsonify({})
   return jsonify(data)

@app.route('/profile/<id>/order/make', methods=['POST'])
def makeorder(id):
   openDb()
   map=request.form
   sql="INSERT INTO `booking`( `id_user`, `id_product`, `date`, `rent_start`, `rent_end`, `total_fee`, `payment_type`, `notes`)"
   sql+=" VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"
   val=(id,map['id_product'],map['date'],map['rent_start'],map['rent_end'],map['total_fee'],map['payment_type'],map['notes'])
   try:
      cursor.execute(sql,val)
      conn.commit()
      closeDb()
      return jsonify({
          "message":"success processing your order",
          "result":True
      })
   except Exception:
      return jsonify({
        "message":"cannot processing your order, please try again later",
        "result":False
      })
# @app.route('/profile/<email>/reset', methods=['POST','PUT'])
# def reset(email):
#    sql="select count(*) as result,id_user as uid from user where email=%s"
#    val=(email)
#    openDb()
#    cursor.execute(sql,val)
#    result=cursor.fetchone()
#    if (result['result']<1):
#        result['message']="your email is not registered"
#        result['result']=False
#        closeDb()
#        return jsonify(result)
#    else:
#        result['result']=True
#        result['message']="your verification has sent, please check your email!"
#        code=random_char(6)
#        sql="replace INTO `verification`(`id_user`, `code`)"
#        sql+=" VALUES (%s,%s)"
#        val =(result["uid"],code)  
#        try:
#             closeDb()
#             openDb()
#             cursor.execute(sql,val)
#             conn.commit()
#             closeDb()
#             msgmail = Message('Verification code', sender = 'mailerfrees@gmail.com', recipients = [email])
#             msgmail.body = "hey this your verification code : "+code
#             mail.send(msgmail)
#             return jsonify(result)
#        except Exception as e:
#             print(str(e))
#             closeDb()
#             return jsonify({
#                 "message":"cannot processing your order, please try again later",
#                 "result":False
#             })
@app.route('/profile/<email>/reset', methods=['POST','PUT'])
def reset(email):
    if request.method== 'PUT':
            sql="select count(*) as result,id_user as uid from user where email=%s"
            val=(email)
            openDb()
            cursor.execute(sql,val)
            result=cursor.fetchone()
            uid=result["uid"]
            closeDb()
            map=request.form
            code=map['code']
            sql="SELECT count(*) as count FROM `verification` WHERE id_user=%s AND code=%s"
            val=(uid,code)
            openDb()
            cursor.execute(sql,val)
            data=cursor.fetchone()
            closeDb()
            if data["count"]<1:
                return jsonify({"result":False,"message":"verification code not match"})
            else:
                sql="DELETE FROM `verification`  WHERE id_user=%s AND code=%s"
                val=(uid,code)
                openDb()
                cursor.execute(sql,val)
                conn.commit()
                closeDb()
                password=hashlib.sha1(map['password'].encode()).hexdigest()
                sql="UPDATE `user` SET `password` =%s WHERE `user`.`id_user` =%s;"
                result={
                    
                }
                try:
                    openDb()
                    cursor.execute(sql,(password,uid))
                    conn.commit()
                    result['result']=True
                    result['message']="change password success"
                    closeDb()
                    return jsonify(result)
                except Exception as e:
                    print(str(e))
                    closeDb()
                    result={
                    "result":False,
                    "message":"cannot change you\'re password"}
                    return jsonify(result)

    else:
       sql="select count(*) as result,id_user as uid from user where email=%s"
       val=(email)
       openDb()
       cursor.execute(sql,val)
       result=cursor.fetchone()
       if (result['result']<1):
           result['message']="your email is not registered"
           result['result']=False
           closeDb()
           return jsonify(result)
       else:
           result['result']=True
           result['message']="your verification has sent, please check your email!"
           code=random_char(6)
           sql="replace INTO `verification`(`id_user`, `code`)"
           sql+=" VALUES (%s,%s)"
           val =(result["uid"],code)  
           try:
                closeDb()
                openDb()
                cursor.execute(sql,val)
                conn.commit()
                closeDb()
                msgmail = Message('Verification code', sender = 'mailerfrees@gmail.com', recipients = [email])
                msgmail.body = "hey this your verification code : "+code
                mail.send(msgmail)
                return jsonify(result)
           except Exception as e:
                print(str(e))
                closeDb()
                return jsonify({
                    "message":"cannot processing your order, please try again later",
                    "result":False
                })

@app.route('/product/image/<filename>')
def geturlfile(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)
if __name__=="__main__":
    app.run(debug=True)

